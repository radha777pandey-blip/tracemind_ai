﻿import logging
from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse

from tracemind.database.connection import get_db
from tracemind.database.schema import init_db
from tracemind.api.routes import router as api_router

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(name)s: %(message)s'
)
logger = logging.getLogger('tracemind')

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup: ensure SQLite database schema is created
    logger.info('Ensuring TraceMind database schema is initialized...')
    with get_db() as conn:
        init_db(conn)
    yield
    logger.info('Shutting down TraceMind API.')

app = FastAPI(
    title='TraceMind AI API',
    description='AI-Powered Codebase Understanding & Change-Impact Analysis Engine',
    version='1.0.0',
    lifespan=lifespan
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=['*'],
    allow_credentials=True,
    allow_methods=['*'],
    allow_headers=['*'],
)

app.include_router(api_router)

@app.get('/api/health')
def health_check():
    return {'status': 'healthy', 'system': 'TraceMind AI', 'version': '1.0.0'}

@app.get('/', response_class=HTMLResponse)
def index():
    return '''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TraceMind AI - Codebase Understanding & Impact Analysis</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Inter', sans-serif; }
        code, pre { font-family: 'JetBrains Mono', monospace; }
    </style>
</head>
<body class="bg-slate-950 text-slate-100 min-h-screen">
    <header class="border-b border-slate-800 bg-slate-900/60 backdrop-blur sticky top-0 z-50 px-6 py-4 flex items-center justify-between">
        <div class="flex items-center space-x-3">
            <div class="w-9 h-9 rounded-lg bg-indigo-600 flex items-center justify-center font-bold text-white shadow-lg shadow-indigo-500/20">TM</div>
            <div>
                <h1 class="text-lg font-bold tracking-tight text-white">TraceMind AI</h1>
                <p class="text-xs text-slate-400">Codebase Understanding & Impact Analysis</p>
            </div>
        </div>
        <div class="flex items-center space-x-3 text-xs">
            <span class="inline-flex items-center px-2.5 py-1 rounded-full font-medium bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                <span class="w-1.5 h-1.5 rounded-full bg-emerald-400 mr-1.5 animate-pulse"></span> Engine Active
            </span>
            <a href="/docs" target="_blank" class="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg border border-slate-700 transition">API Docs</a>
        </div>
    </header>

    <main class="max-w-7xl mx-auto px-6 py-8 grid grid-cols-1 lg:grid-cols-3 gap-8">
        <!-- Ingestion & Control Column -->
        <div class="space-y-6">
            <div class="bg-slate-900/80 border border-slate-800 rounded-xl p-5 shadow-sm">
                <h2 class="text-sm font-semibold text-slate-200 uppercase tracking-wider mb-4 flex items-center">
                    <svg class="w-4 h-4 mr-2 text-indigo-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12"></path></svg>
                    1. Ingest Codebase
                </h2>
                <div class="space-y-3">
                    <div>
                        <label class="text-xs font-medium text-slate-400">Directory Path</label>
                        <input id="ingestPath" type="text" value="samples/ecommerce" class="mt-1 w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-200 focus:outline-none focus:border-indigo-500 font-mono">
                    </div>
                    <div>
                        <label class="text-xs font-medium text-slate-400">Repository Name</label>
                        <input id="ingestName" type="text" value="Ecommerce Demo" class="mt-1 w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-200 focus:outline-none focus:border-indigo-500">
                    </div>
                    <button id="btnIngest" onclick="ingestRepo()" class="w-full mt-2 bg-indigo-600 hover:bg-indigo-500 text-white font-medium py-2 px-4 rounded-lg text-sm transition shadow-lg shadow-indigo-600/20">
                        Scan & Ingest Codebase
                    </button>
                    <div id="ingestStatus" class="text-xs text-slate-400 hidden"></div>
                </div>
            </div>

            <div class="bg-slate-900/80 border border-slate-800 rounded-xl p-5 shadow-sm">
                <h2 class="text-sm font-semibold text-slate-200 uppercase tracking-wider mb-4 flex items-center">
                    <svg class="w-4 h-4 mr-2 text-amber-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"></path></svg>
                    Repositories
                </h2>
                <div id="repoList" class="space-y-2 text-sm">
                    <p class="text-xs text-slate-500">Loading repositories...</p>
                </div>
            </div>
        </div>

        <!-- Main Workspace (Impact Analysis & Q&A) -->
        <div class="lg:col-span-2 space-y-6">
            <!-- Impact Analysis Card -->
            <div class="bg-slate-900/80 border border-slate-800 rounded-xl p-6 shadow-sm">
                <div class="flex items-center justify-between mb-4">
                    <h2 class="text-sm font-semibold text-slate-200 uppercase tracking-wider flex items-center">
                        <svg class="w-4 h-4 mr-2 text-rose-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"></path></svg>
                        Change-Impact Analysis (Blast Radius)
                    </h2>
                    <span class="text-xs bg-rose-500/10 text-rose-400 border border-rose-500/20 px-2 py-0.5 rounded font-medium">Core Feature</span>
                </div>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-3 mb-4">
                    <div>
                        <label class="text-xs font-medium text-slate-400">File Path</label>
                        <input id="impactFile" type="text" placeholder="e.g. auth.py" value="auth.py" class="mt-1 w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-200 focus:outline-none focus:border-indigo-500 font-mono">
                    </div>
                    <div>
                        <label class="text-xs font-medium text-slate-400">Target Function / Class (Optional)</label>
                        <input id="impactEntity" type="text" placeholder="e.g. get_current_user" value="get_current_user" class="mt-1 w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-200 focus:outline-none focus:border-indigo-500 font-mono">
                    </div>
                </div>
                <button onclick="runImpact()" class="w-full bg-rose-600 hover:bg-rose-500 text-white font-medium py-2 px-4 rounded-lg text-sm transition shadow-lg shadow-rose-600/20">
                    Analyze Change Blast Radius
                </button>

                <div id="impactResults" class="mt-6 hidden space-y-4">
                    <div id="impactBanner" class="p-4 rounded-lg border"></div>
                    <div class="space-y-2">
                        <h3 class="text-xs font-semibold text-slate-400 uppercase tracking-wider">Potentially Affected Components:</h3>
                        <div id="impactList" class="space-y-2"></div>
                    </div>
                </div>
            </div>

            <!-- Codebase Q&A Card -->
            <div class="bg-slate-900/80 border border-slate-800 rounded-xl p-6 shadow-sm">
                <h2 class="text-sm font-semibold text-slate-200 uppercase tracking-wider mb-4 flex items-center">
                    <svg class="w-4 h-4 mr-2 text-cyan-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z"></path></svg>
                    Semantic Codebase Q&A (RAG)
                </h2>
                <div class="flex space-x-2 mb-4">
                    <input id="qaInput" type="text" placeholder="Ask anything about the codebase (e.g., 'How does checkout work?')" value="How does the order creation and checkout flow work?" class="flex-1 bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-200 focus:outline-none focus:border-indigo-500">
                    <button onclick="askQuestion()" class="bg-cyan-600 hover:bg-cyan-500 text-white font-medium py-2 px-4 rounded-lg text-sm transition">
                        Ask
                    </button>
                </div>

                <div id="qaResults" class="mt-4 hidden space-y-4">
                    <div class="bg-slate-950 border border-slate-800 rounded-lg p-4">
                        <div class="flex items-center justify-between mb-2">
                            <span class="text-xs font-semibold uppercase tracking-wider text-slate-400">Answer</span>
                            <span id="qaMode" class="text-xs text-cyan-400 bg-cyan-500/10 border border-cyan-500/20 px-2 py-0.5 rounded"></span>
                        </div>
                        <div id="qaAnswer" class="text-sm text-slate-300 leading-relaxed whitespace-pre-line"></div>
                    </div>
                    <div>
                        <h3 class="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">Source Citations:</h3>
                        <div id="qaCitations" class="space-y-2"></div>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <script>
        let selectedRepoId = null;

        async function loadRepos() {
            try {
                const res = await fetch('/api/repositories');
                const repos = await res.json();
                const container = document.getElementById('repoList');
                if (repos.length === 0) {
                    container.innerHTML = '<p class="text-xs text-slate-500">No repositories ingested yet.</p>';
                    return;
                }
                container.innerHTML = repos.map(r => 
                    <div onclick="selectRepo()" class="p-3 rounded-lg border  cursor-pointer transition">
                        <div class="font-medium text-slate-200"></div>
                        <div class="text-xs text-slate-400 font-mono mt-0.5 truncate"></div>
                        <div class="text-xs text-slate-500 mt-2 flex space-x-3">
                            <span>Files: </span>
                            <span>Entities: </span>
                        </div>
                    </div>
                ).join('');
                if (!selectedRepoId && repos.length > 0) {
                    selectRepo(repos[0].id);
                }
            } catch (err) {
                console.error(err);
            }
        }

        function selectRepo(id) {
            selectedRepoId = id;
            loadRepos();
        }

        async function ingestRepo() {
            const path = document.getElementById('ingestPath').value.trim();
            const name = document.getElementById('ingestName').value.trim();
            const status = document.getElementById('ingestStatus');
            const btn = document.getElementById('btnIngest');

            status.classList.remove('hidden');
            status.innerHTML = '<span class="text-indigo-400">Scanning, parsing AST, and indexing...</span>';
            btn.disabled = true;

            try {
                const res = await fetch('/api/repositories/ingest', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ path, name })
                });
                const data = await res.json();
                if (res.ok) {
                    status.innerHTML = <span class="text-emerald-400">Successfully indexed  files,  entities,  relations!</span>;
                    selectedRepoId = data.repo_id;
                    await loadRepos();
                } else {
                    status.innerHTML = <span class="text-rose-400">Error: </span>;
                }
            } catch (err) {
                status.innerHTML = <span class="text-rose-400">Error: </span>;
            } finally {
                btn.disabled = false;
            }
        }

        async function runImpact() {
            if (!selectedRepoId) {
                alert('Please ingest or select a repository first!');
                return;
            }
            const file_path = document.getElementById('impactFile').value.trim();
            const entity_name = document.getElementById('impactEntity').value.trim();
            const container = document.getElementById('impactResults');
            const banner = document.getElementById('impactBanner');
            const list = document.getElementById('impactList');

            container.classList.remove('hidden');
            banner.innerHTML = '<span class="text-slate-400">Traversing dependency graph blast radius...</span>';
            list.innerHTML = '';

            try {
                const res = await fetch(/api/repositories//impact-analysis, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ file_path, entity_name, max_depth: 3 })
                });
                const data = await res.json();
                if (res.ok) {
                    const riskColor = data.highest_risk === 'HIGH' ? 'border-rose-500/30 bg-rose-500/10 text-rose-300' : 'border-amber-500/30 bg-amber-500/10 text-amber-300';
                    banner.className = p-4 rounded-lg border ;
                    banner.innerHTML = 
                        <div class="font-semibold text-sm mb-1">Impact Level:  Risk</div>
                        <div class="text-xs opacity-90"></div>
                    ;

                    if (data.affected_items.length === 0) {
                        list.innerHTML = '<p class="text-xs text-slate-500">No dependent components found. Modifying this entity has zero blast radius.</p>';
                    } else {
                        list.innerHTML = data.affected_items.map(item => 
                            <div class="p-3 bg-slate-950 border border-slate-800 rounded-lg text-xs space-y-1">
                                <div class="flex items-center justify-between">
                                    <span class="font-semibold text-slate-200 font-mono"> ()</span>
                                    <span class="px-2 py-0.5 rounded text-[10px] font-bold ">
                                        Depth  • 
                                    </span>
                                </div>
                                <div class="text-slate-400 font-mono"></div>
                                <div class="text-slate-300 mt-1"></div>
                            </div>
                        ).join('');
                    }
                } else {
                    banner.className = 'p-4 rounded-lg border border-rose-500/30 bg-rose-500/10 text-rose-300';
                    banner.innerText = data.detail || 'Analysis failed.';
                }
            } catch (err) {
                banner.innerText = err.message;
            }
        }

        async function askQuestion() {
            if (!selectedRepoId) {
                alert('Please ingest or select a repository first!');
                return;
            }
            const query = document.getElementById('qaInput').value.trim();
            const container = document.getElementById('qaResults');
            const answerDiv = document.getElementById('qaAnswer');
            const citationsDiv = document.getElementById('qaCitations');
            const modeSpan = document.getElementById('qaMode');

            container.classList.remove('hidden');
            answerDiv.innerHTML = '<span class="text-slate-400">Searching embeddings & synthesizing answer...</span>';
            citationsDiv.innerHTML = '';

            try {
                const res = await fetch(/api/repositories//query, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ query, top_k: 4 })
                });
                const data = await res.json();
                if (res.ok) {
                    modeSpan.innerText = 'Engine: ' + data.mode;
                    answerDiv.innerText = data.answer;
                    citationsDiv.innerHTML = data.citations.map(c => 
                        <div class="p-3 bg-slate-950 border border-slate-800 rounded-lg text-xs">
                            <div class="font-mono text-indigo-400 font-semibold mb-1"> (lines -)</div>
                            <pre class="text-slate-400 overflow-x-auto text-[11px] p-2 bg-slate-900 rounded"></pre>
                        </div>
                    ).join('');
                } else {
                    answerDiv.innerText = data.detail || 'Query failed';
                }
            } catch (err) {
                answerDiv.innerText = err.message;
            }
        }

        // Auto load on start
        loadRepos();
    </script>
</body>
</html>'''

